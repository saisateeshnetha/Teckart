import React from 'react'

function ViewSupport() {
  return (
    <div>ViewSupport</div>
  )
}

export default ViewSupport