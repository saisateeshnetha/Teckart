const baseUrl = "http://13.48.248.120:5025/";
export const URL={
    allbanners:baseUrl+"api/v1/admin/carBanner/getallcarbanners",


}